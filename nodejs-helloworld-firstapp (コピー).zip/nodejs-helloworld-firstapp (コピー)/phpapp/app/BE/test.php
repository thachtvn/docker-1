<?php
$mysqli = new mysqli("mysql","root", "root", "db_test");

$query = $mysqli->prepare("SELECT * FROM test");
$query->execute();
$query->store_result();

$rows = $query->num_rows;

echo $rows;

// Return 4 for example
?>