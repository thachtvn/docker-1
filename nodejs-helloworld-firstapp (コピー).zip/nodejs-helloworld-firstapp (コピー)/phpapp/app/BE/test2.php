<?php
header('Content-Type: text/html;charset=UTF-8');

$mysqli = new mysqli("mysql","root", "root", "db_test");
mysqli_set_charset( $mysqli,"utf8" );
// $query = $mysqli->prepare("SELECT * FROM ユーザー");
// $query->execute();
// $query->store_result();

// $rows = $query->num_rows;

// echo $rows;
$select_query = "SELECT * FROM ユーザー";
$select_query = mb_convert_encoding($select_query, 'UTF-8');
$result = $mysqli->query($select_query);
$rows = mysqli_num_rows($result);
echo $rows;
echo "-------------";
$select_query = "SELECT * FROM test";
$select_query = mb_convert_encoding($select_query, 'UTF-8');
$result = $mysqli->query($select_query);
$rows = mysqli_num_rows($result);
echo $rows;
// Return 4 for example
?>