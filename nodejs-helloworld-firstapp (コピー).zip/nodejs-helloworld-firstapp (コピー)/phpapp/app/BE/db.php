<?php
	$conn = new mysqli("mysql","root","root","db_test");
	if ($conn->connect_error) {
		die("Connection failed: " . $conn->connect_error);
	}

	// echo "Connected successfully";
	mysqli_set_charset( $conn,"utf8" );
		
?>