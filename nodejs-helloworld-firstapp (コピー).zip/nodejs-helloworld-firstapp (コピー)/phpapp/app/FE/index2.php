<html>
<head>
    <title></title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <script defer src="../assets/fontawesome/js/all.js"></script>
</head>
<body>
<p class="text-left"><i class="fas fa-user"></i> マイアカウント <i class="fas fa-chevron-right"></i> 会員情報のご変更</p>
<div class="text-center">
    <img src="../assets/u_construction.png" width="65%">
</div>
</body>
</html>
